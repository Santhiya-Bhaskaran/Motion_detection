﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video.DirectShow;
using AForge.Vision.Motion;

namespace motio
{
	public partial class Form1 : Form
	{
		FilterInfoCollection devices;
		VideoCaptureDevice camera = new VideoCaptureDevice();

		MotionDetector detector;
		float detectionLevel, sensitivity;

		BlobCountingObjectsProcessing motionProcessing = new BlobCountingObjectsProcessing();
		private SerialPort serialPort;

		private int imageCounter = 0; // ✅ unique file name counter

		public Form1()
		{
			InitializeComponent();

			// Placeholder in email textbox
			textBox2.GotFocus += RemoveText;
			textBox2.LostFocus += AddText;
		}

		private void RemoveText(object sender, EventArgs e)
		{
			if (textBox2.Text == "Enter email")
			{
				textBox2.Text = "";
				textBox2.ForeColor = Color.Black;
			}
		}

		private void AddText(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(textBox2.Text))
			{
				textBox2.Text = "Enter email";
				textBox2.ForeColor = Color.Gray;
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			sensitivity = 0.02f;
			detector = new MotionDetector(new TwoFramesDifferenceDetector(), new BlobCountingObjectsProcessing());

			detectionLevel = 0;

			devices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
			foreach (FilterInfo d in devices)
			{
				comboBox1.Items.Add(d.Name);
			}
			if (comboBox1.Items.Count > 0)
				comboBox1.SelectedIndex = 0;
		}

		private void startButton_Click(object sender, EventArgs e)
		{
			// ✅ Validate email before starting
			if (textBox2.Text == "Enter email" || string.IsNullOrWhiteSpace(textBox2.Text) || !textBox2.Text.Contains("@"))
			{
				DialogResult result = MessageBox.Show(
					"You have not entered a valid email.\nDo you want to continue with default email (bsvssangeetha@gmail.com)?",
					"Email Missing",
					MessageBoxButtons.YesNo,
					MessageBoxIcon.Warning
				);

				if (result == DialogResult.No)
				{
					return; // stop starting if user declines
				}
				else
				{
					textBox2.Text = "bsvssangeetha@gmail.com"; // ✅ fallback email
				}
			}

			if (camera.IsRunning == true)
			{
				camera.Stop();
			}

			camera = new VideoCaptureDevice(devices[comboBox1.SelectedIndex].MonikerString);
			videoSourcePlayer1.VideoSource = camera;
			videoSourcePlayer1.Start();

			timer1.Start(); // ✅ start detection timer
		}

		private void stopButton_Click(object sender, EventArgs e)
		{
			timer1.Enabled = false;
			detectionLevel = 0;
			videoSourcePlayer1.SignalToStop();
			if (camera.IsRunning)
				camera.Stop();
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			if (detectionLevel > 0 && checkBox1.Checked == true)
			{
				SaveFrameAndSendAlert();
			}
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (camera.IsRunning == true)
			{
				detectionLevel = 0;
				videoSourcePlayer1.SignalToStop();
				camera.Stop();
			}
		}

		private void videoSourcePlayer1_NewFrame_1(object sender, ref Bitmap image)
		{
			if (detector.ProcessFrame(image) > sensitivity)
			{
				detectionLevel = detector.ProcessFrame(image);
				notify();
			}
		}

		private void notify()
		{
			if (checkBox1.Checked == true)
			{
				SaveFrameAndSendAlert();
			}
		}

		private void SaveFrameAndSendAlert()
		{
			try
			{
				System.Media.SoundPlayer player = new System.Media.SoundPlayer();
				player.SoundLocation = "sound.wav";
				player.Play();

				Bitmap bitmap = videoSourcePlayer1.GetCurrentVideoFrame();

				// ✅ unique file name
				string fileName = $"image_{imageCounter++}.jpg";
				string filePath = Application.StartupPath + "/" + fileName;

				bitmap.Save(filePath);
				bitmap.Dispose();

				detectionLevel = 0;
				SendMotionAlert(filePath);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error while processing frame: " + ex.Message);
			}
		}

		private void trackBar1_ValueChanged(object sender, EventArgs e)
		{
			sensitivity = trackBar1.Value * 0.01f;
		}

		// ✅ Sends motion alert email with snapshot
		public void SendMotionAlert(string attachmentPath)
		{
			try
			{
				DateTime now = DateTime.Now;
				string time = now.ToString();

				string senderEmail = "bsvssanthiya9@gmail.com";
				string senderPassword = "rbsaxzkxihgqhuao";

				string recipientEmail = (textBox2.Text == "Enter email" || string.IsNullOrWhiteSpace(textBox2.Text))
					? "bsvssangeetha@gmail.com"
					: textBox2.Text;

				Attachment att = new Attachment(attachmentPath);

				SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
				client.EnableSsl = true;
				client.UseDefaultCredentials = false;
				client.Credentials = new NetworkCredential(senderEmail, senderPassword);

				MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail);
				mailMessage.Subject = "🚨 Motion Detected!";
				mailMessage.Body = "Motion has been detected by the security system at " + time;
				mailMessage.Attachments.Add(att);

				client.Send(mailMessage);
				MessageBox.Show("📩 Motion alert email sent to " + recipientEmail);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error sending motion alert: " + ex.Message);
			}
		}

		// ✅ Sends a simple test email without snapshot
		public void SendTestMail()
		{
			try
			{
				string senderEmail = "bsvssanthiya9@gmail.com";
				string senderPassword = "rbsaxzkxihgqhuao";

				string recipientEmail = (textBox2.Text == "Enter email" || string.IsNullOrWhiteSpace(textBox2.Text))
					? "bsvssangeetha@gmail.com"
					: textBox2.Text;

				SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
				client.EnableSsl = true;
				client.UseDefaultCredentials = false;
				client.Credentials = new NetworkCredential(senderEmail, senderPassword);

				MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail);
				mailMessage.Subject = "✅ Test Email - Security System";
				mailMessage.Body = "This is a test email to confirm that the notification system is working correctly.";

				client.Send(mailMessage);
				MessageBox.Show("📩 Test email sent successfully to " + recipientEmail);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error sending test email: " + ex.Message);
			}
		}

		// ✅ "Test Mail" button calls only test mail
		private void button1_Click(object sender, EventArgs e)
		{
			SendTestMail();
		}
	}
}
